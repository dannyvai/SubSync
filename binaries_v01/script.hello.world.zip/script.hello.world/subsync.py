import sys
import os
import argparse
import glob
import subprocess
import json
import re
import time

import xbmc

from keys import *
import np_alternative as np
import pysrt
import SubsceneDL



def is_common_word(word):
    return word in ('i','you','are','is','the','a','%HESITATION')

def fix_srt(srt_path,start_t,end_t):

    srt = pysrt.open(srt_path)
    for i in range(0,len(srt)):
        #print srt[i].start
        seconds_to_srt_time(srt[i].start,start_t[i])
        seconds_to_srt_time(srt[i].end,end_t[i])

    srt.save(srt_path+".fixed.srt", encoding='utf-8')
    return srt_path+".fixed.srt"
    #srt.save("test.srt", encoding='utf-8')

def calculate_subtitle_shift(
    sample_times,
    sample_duration,
    min_words,
    shift_wanted,
    diff_segments,
    start_t,
    end_t,
    first_sentance_words
):

    diff_mean_vec = []
    diff_time_vec = []
    num_segments = len(sample_times)

    for seg_idx in range(0,num_segments):
        #print diff_segments[seg_idx]
        if not len(diff_segments[seg_idx]) <  min_words:
            diff_mean_vec.append(np.mean_list(diff_segments[seg_idx]))
            diff_time_vec.append(sample_times[seg_idx] + sample_duration/2.)
        else:
            print "diff_segments[seg_idx].size <  min_words"

    #print diff_mean_vec
    #print diff_time_vec
    for i in range (0,len(start_t)):
        ts = start_t[i]
        te = end_t[i]
        if ts < diff_time_vec[0]:
            shift = diff_mean_vec[0] - shift_wanted
        elif ts > diff_time_vec[-1]:
            shift = diff_mean_vec[-1] - shift_wanted
        else:
            shift = np.interp1d_list(diff_time_vec,diff_mean_vec,ts) - shift_wanted

        start_t[i] += shift
        end_t[i] += shift


def compare_words(
    sample_times,
    sample_duration,
    video_path,
    output_template,
    temp_dir,
    search_win,
    start_t,
    first_sentance_words,
    min_words,
    max_dist
):

    video_name = get_video_name_from_path(video_path)
    num_segments = len(sample_times)
    diff_segments = []

    for seg_idx in range(0,num_segments):
        start_time = sample_times[seg_idx]

        extracted_text_output_json_filename = output_template.format(
                video_name,sample_duration,seg_idx,num_segments)

        result = json.loads(open(os.path.join(temp_dir,extracted_text_output_json_filename),'r').read())
        if 'results' not in result.keys():
            #TODO should be NaN
            print("Should be NaN :: 'results' not in result.keys():")
            diff_segments.append([0])
            continue

        t_ws_vid_vec = []
        t_ws_srt_vec = []
        match_words = []

        for res in result['results']:
            for sample in res['alternatives'][0]['timestamps']:
                word,word_start_sample,word_end_sample = sample
                word = word.strip().lower()

                if is_common_word(word):
                    continue

                if len(word) == 0:
                    continue

                time_word_start = start_time + word_start_sample
                time_min = time_word_start - search_win
                time_max = time_word_start + search_win
                #print time_min,time_max
                min_idx = np.list_where_gt(start_t, time_min)
                max_idx = np.list_where_lt(start_t, time_max)
                #print "Min",min_idx
                #print "Max",max_idx
                intersection = np.intersect1d_list(min_idx,max_idx)
                #print "Inter",intersection

                for word_idx in intersection:
                    word_srt = first_sentance_words[word_idx]
                    #print word_srt,word,word_srt == word
                    if word_srt == word:
                        t_ws_vid_vec.append(time_word_start)
                        t_ws_srt_vec.append(start_t[word_idx])
                        match_words.append(word)
                        break

        if len(match_words) == 0:
            #TODO should be NaN
            print("Should be NaN :: len(match_words) == 0")
            diff_segments.append([0])
        elif len(match_words) < min_words:
            #TODO should be NaN
            print("Should be NaN :: len(match_words) < min_words")
            diff_segments.append([0])
        else:

            diff_temp = np.subtract_lists(t_ws_vid_vec,t_ws_srt_vec)
            #print "Diff temp:: " ,diff_temp
            diff_m = np.median_list(diff_temp)
            #print "Median::",diff_m
            dist = np.subtract_list_const(diff_temp, diff_m)
            #print "Dist",dist
            #print "Max dist :: ",max_dist
            i_ok = np.list_where_lt(np.list_abs(dist), max_dist)
            diff_temp = np.list_on_indices(diff_temp,i_ok)
            #print "Diff temp :: ",diff_temp
            #print match_words
            #print t_ws_vid_vec
            #print t_ws_srt_vec
            if len(diff_temp)  < min_words :
                #TODO should be NaN
                print("Should be NaN :: i_ok[0].size  < min_words")
                diff_segments.append([0])
            else :
                diff_segments.append(diff_temp)

    return diff_segments



def remove_non_ascii(text):
    return "".join(i for i in text if ord(i)<128)

def decode_utf8_bom(srt_fname):
    fp = open(srt_fname,'r')
    content_raw = remove_non_ascii(fp.read())
    fp.close()

    content_utf8bom = content_raw.decode('utf-8')
    content_ascii = content_utf8bom.encode('ascii')

    fp = open(srt_fname,'w')
    fp.write(content_ascii)
    fp.close()


def srt_time_to_seconds(srt_time):
    return srt_time.hours*3600 + srt_time.minutes*60 + srt_time.seconds + srt_time.milliseconds/1000.0

def seconds_to_srt_time(srt_time,sec):

    hours = int(sec/3600.)
    minutes = int((sec%3600)/60.)
    seconds = int(sec%60)
    milliseconds = int(sec%1*1000)
    #print sec,hours,minutes,seconds,milliseconds

    srt_time.hours = hours
    srt_time.minutes = minutes
    srt_time.seconds = seconds
    srt_time.milliseconds = milliseconds

def read_srt(srt_fname):
    start_t = []
    end_t = []
    first_sentance_words = []

    decode_utf8_bom(srt_fname)

    srt = pysrt.open(srt_fname)
    for line in srt:
        start_t.append(srt_time_to_seconds(line.start))
        end_t.append(srt_time_to_seconds(line.end))
        if len( line.text.strip()) == 0:
            word = 'skdlfjksldfjsdklfjsldkgjsd'
        else:
            word = line.text.split()[0].lower()
            word = re.sub('[,\.><!\?]','',word)
        #TODO check if common word and take the other one?
        first_sentance_words.append(word)

    return start_t,end_t,first_sentance_words

def extract_text_from_video_segment(start_time,sample_duration,video_path,extracted_text_output_json_filename,temp_dir):

    audio_sample_filename = "seg_{}_of_{}.ogg".format(int(start_time),int(start_time+sample_duration))
    temp_folder = temp_dir
    temp_script_name = r'{}{}{}_{}.bat'.format(temp_folder,os.sep,start_time,(start_time+sample_duration))
    temp_script = open(temp_script_name,'w')
    sample_audio_cmd = r'c:\subsync_bin\ffmpeg -i "{}" -ss {} -t {} -vn -acodec libvorbis -y {}{}{}'.format(video_path,start_time,sample_duration,temp_folder,os.sep,audio_sample_filename)
    #os.system(sample_audio_cmd)
    tts_cmd = r'c:\subsync_bin\curl -X POST -u {}:{} --header "Content-Type: audio/ogg;codecs=vorbis" --header "Transfer-Encoding: chunked" --data-binary @{}{}{} "https://stream.watsonplatform.net/speech-to-text/api/v1/recognize?continuous=true&timestamps=true&max_alternatives=1"  > "{}{}{}_temp" '.format(IBM_USER,IBM_PASSWORD,temp_folder,os.sep,audio_sample_filename,temp_folder,os.sep,extracted_text_output_json_filename)
    #os.system(tts_cmd)

    print sample_audio_cmd
    print tts_cmd

    print >> temp_script , sample_audio_cmd
    print >> temp_script , tts_cmd
    print >> temp_script , 'rename "{}{}{}_temp" "{}"'.format(temp_folder,os.sep,extracted_text_output_json_filename,extracted_text_output_json_filename)
    print >> temp_script , "exit"
    temp_script.close()
    os.system('start {}'.format(temp_script_name))

def extract_text_from_video(sample_times,sample_duration,video_path,output_template,temp_dir):

    threads = []
    video_name = get_video_name_from_path(video_path)
    output_names = []
    for seg_idx in range(0,len(sample_times)):

        start_time = sample_times[seg_idx]

        extracted_text_output_json_filename = output_template.format(
                video_name,sample_duration,seg_idx,len(sample_times))

        if not os.path.exists(os.path.join(temp_dir,extracted_text_output_json_filename)):
            #t = threading.Thread(target=extract_text_from_video_segment,args=(start_time,sample_duration,video_path,extracted_text_output_json_filename,))
            #threads.append(t)
            #t.start()
            extract_text_from_video_segment(start_time,sample_duration,video_path,extracted_text_output_json_filename,temp_dir)
            output_names.append(os.path.join(temp_dir,extracted_text_output_json_filename))
    #for thread in threads:
    #   threads.join()
    all_outputs_exist = False
    while not all_outputs_exist:
        all_outputs_exist = True
        for name in output_names:
            if not os.path.exists(name):
                all_outputs_exist = False
                break
        time.sleep(5)

    print "All threads finished"


def get_video_duration(video_path):
    
    xbmc.log('get_video_duration',xbmc.LOGERROR)
    command = [
        "/usr/local/bin/ffprobe",
        "-loglevel",  "quiet",
        "-print_format", "json",
        "-show_format",
        video_path
     ]

    pipe = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out, err = pipe.communicate()
    output = json.loads(out)
    return float(output['format']['duration'])

def find_srt_file(video_name,where='.'):

    files = os.listdir(where)

    srt_fname = None
    for fname in files:
        not_my_file = False
        if ".srt" in fname:
            for word in video_name.lower().split():
                if word not in fname.lower():
                    not_my_file = True
                    break
            if not not_my_file:
                srt_fname = fname
                break
    if srt_fname is None:
        return None
    return os.path.join(where,srt_fname)

def download_subtitles(video_name,where='.'):
    SubsceneDL.download_srt(video_name)
    #os.system('python SubsceneDL.py -d {} -m {}'.format(where,video_name))

def get_video_name_from_path(video_path):
    return video_path.split(os.path.sep)[-1].split('.')[0]

def download_and_create_shifted_srt(video_path,video_name,video_duration,output_dir,to_download=True,subtitle_file='',xbmc_progess_dialog=None):
    

    credits_length = 30; #Seconds
    intro_length = 30; #Seconds
    sample_duration = 60; #Seconds
    win = 5;  #Seconds
    num_of_seg = 15;
    max_dist = 0.3; #Seconds
    min_words = 4;
    shift_wanted = 0.1; #Seconds

    #video_name = get_video_name_from_path(video_path)

    xbmc.log("Video path is : {} ".format(video_path),xbmc.LOGERROR)

    xbmc.log("Video name is : {} ".format(video_name),xbmc.LOGERROR)

    xbmc_progess_dialog.update(20,message="Downloading Subtitle")
    if to_download or subtitle_file == '':
        srt_file = find_srt_file(video_name,output_dir)
        if srt_file is None:
            download_subtitles(video_name,output_dir)
            srt_file = find_srt_file(video_name,output_dir)
    else:
        srt_file = subtitle_file

    if srt_file is not None:
        xbmc.log("Found srt: {}".format(srt_file),xbmc.LOGERROR)
    else:
        xbmc.log("no subtitles were found :{",xbmc.LOGERROR)
        sys.exit(-1)

    #video_duration = get_video_duration(video_path)
    xbmc.log("Video duration : {}".format(video_duration),xbmc.LOGERROR)

    sampled_duration = video_duration - credits_length - intro_length
    #print np.linspace_list(intro_length,video_duration-sample_duration,num_of_seg)

    sample_times = np.list_floor(np.linspace_list(intro_length,video_duration-sample_duration,num_of_seg))
    print("Time samples:",sample_times)
    
    
    start_t,end_t,first_sentance_words = read_srt(srt_file)

    tts_output_template = '{}_dur_{}_seg_{}_of_{}.json'
    temp_dir = r"c:\temp\\"

    files = glob.glob(os.path.join(temp_dir,"*"))
    for f in files:
        os.remove(f)
    
    xbmc_progess_dialog.update(40,message="Extracting text from speech AKA you are costing us money")
    extract_text_from_video(sample_times,sample_duration,video_path,tts_output_template,temp_dir)

    xbmc_progess_dialog.update(60,message="Doing complicated sutff!!")
    diff_segments = compare_words(sample_times,sample_duration,video_path,tts_output_template,temp_dir,win,start_t,first_sentance_words,min_words,max_dist)

    #rint start_t
    #print end_t
    xbmc_progess_dialog.update(80,message="Calculating subtitle shift")
    calculate_subtitle_shift(sample_times,sample_duration,min_words,shift_wanted,diff_segments,start_t,end_t,first_sentance_words)
    #print start_t
    #print end_t
    xbmc_progess_dialog.update(90,message="Fixng Subtitles")
    fixed_subs = fix_srt(srt_file,start_t,end_t)
    xbmc_progess_dialog.update(100,message="Subtitles has been fixed")
    return fixed_subs

def main():

    parser = argparse.ArgumentParser(description='SubSync')

    parser.add_argument('-f','--filename',help='filename path',default='')
    parser.add_argument('-od','--dir',help='output dir',default='.')
    parser.add_argument('-d','--download',dest='download',help='download subtitles',action='store_true')
    parser.add_argument('-nd','--no-download',dest='download',help='Dont download subtitles',action='store_false')
    parser.add_argument('-s','--subtitle',help='subtitle file',default='')
    args = parser.parse_args()

    video_path = args.filename
    output_dir = args.dir
    to_download=args.download
    subtitle_file = args.subtitle

    download_and_create_shifted_srt(video_path,output_dir,to_download,subtitle_file)


if __name__ == "__main__":
    main()
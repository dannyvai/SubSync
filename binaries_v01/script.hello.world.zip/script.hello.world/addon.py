import xbmcaddon
import xbmcgui
import xbmc
import time
import os
import math
import subsync
import platform

finished = False

def pause_stream_if_not_finished():
    global finished
    if finished:
        pass
    else:
        xbmc.Player().pause()


addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


xbmc.Player().onPlayBackResumed(pause_stream_if_not_finished)

isPlayingVideo  = xbmc.Player().isPlayingVideo()
if isPlayingVideo:

    #Pause the current playing file
    xbmc.Player().pause()
    #for sub_stream in xbmc.Player().getAvailableSubtitleStreams():
    #    #xbmc.log(msg=sub_stream, level=xbmc.LOGINFO)
    #    os.system('echo "{}" >> /Users/dwainshtein/workspace/SubSync_git/output.txt'.format(sub_stream))
    playing_file = xbmc.Player().getPlayingFile()
    video_tag = xbmc.Player().getVideoInfoTag()
    video_duration = xbmc.Player().getTotalTime()
    title = video_tag.getTitle()
    episode = video_tag.getEpisode()
    is_movie = False
    if episode == -1:
        is_movie = True
    else:
        season = video_tag.getSeason()
        tv_show_title = video_tag.getTVShowTitle()
    #get the name of the file
    if len(title) == 0:
        title = ' '.join(playing_file.split(os.sep)[-1].split('.')[:-1])
    if not is_movie:
        title = "{} s{:02d}e{:02d}".format(tv_show_title,int(season),int(episode))
    
    xbmcgui.Dialog().ok('SubSync',str(title),"Is movie ? : {}".format(is_movie),playing_file)

    pDialog = xbmcgui.DialogProgressBG()
    
    pDialog.create('SubSync', 'Finding the best subtitles, just chill')

    subs_file = subsync.download_and_create_shifted_srt(playing_file,title,video_duration,r'C:\Users\orubi',True,'',pDialog)
    
    #os.system('pwd >> /Users/dwainshtein/workspace/SubSync_git/output.txt'.format(sub_stream))
    #cwd = os.getcwd()
    #os.system('echo "{}" >> /Users/dwainshtein/workspace/SubSync_git/output.txt'.format(cwd))


    #os.system('cd /Users/dwainshtein/workspace/SubSync_git/;/usr/local/bin/python2.7 parse_srt.py -f "{}" -d'.format(playing_file))
    #os.system('ping 8.8.8.8 -n 10')
    #print "Test"
    xbmc.Player().setSubtitles(subs_file)
    pDialog.update(100,message="Enjoy!")
    pDialog.close()
    xbmc.Player().pause()